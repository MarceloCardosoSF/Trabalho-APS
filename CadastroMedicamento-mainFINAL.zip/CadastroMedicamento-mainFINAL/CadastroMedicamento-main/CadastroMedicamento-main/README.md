# Sistema para Gerencimento de Medicamento [Em desenvolvimento]
## ADS - Faculdades SENAC - Maringá

```
Linguagem Java com Swing
```
```
Persistência em Objeto com ArrayList
```
```
IDE intellij
```
