package apresentacao.ExcluirMedicamento;

import Negocio.Medicamento;
import persistencia.ControlaMedicamento;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.format.DateTimeFormatter;

public class ExcluirMedicamento extends JFrame {
    private JTextField idmed;
    private JButton pesquisarButton;
    private JTextField nomeMed;
    private JTextField regMs;
    private JTextField datVal;
    private JButton excluirButton;
    private JButton Cancelar;
    private javax.swing.JPanel JPanel;

    ControlaMedicamento cm;
    public ExcluirMedicamento(ControlaMedicamento cm) {
        setContentPane(JPanel);
        setTitle("Excluir Medicamento");
      //  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setSize(700, 400);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        pesquisarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = Integer.valueOf(idmed.getText());
                Medicamento med = cm.PesquisarMed(id);
                nomeMed.setText(med.getNome());
                regMs.setText(med.getRegistroms());
                datVal.setText(med.getDataValidade().format(formatter));
            }
            });
        Cancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
dispose();
            }
    });
        excluirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = Integer.valueOf(idmed.getText())   ;
                Medicamento med = cm.PesquisarMed(id);
                cm.ExcluirMed(id);
            }
        });
    };
}