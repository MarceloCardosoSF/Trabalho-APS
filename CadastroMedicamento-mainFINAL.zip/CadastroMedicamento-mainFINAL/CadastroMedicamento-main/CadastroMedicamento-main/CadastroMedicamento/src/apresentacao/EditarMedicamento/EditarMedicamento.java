package apresentacao.EditarMedicamento;

import Negocio.Medicamento;
import persistencia.ControlaMedicamento;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class EditarMedicamento extends JFrame {
    private JPanel JPanel;
    private JTextField idmed;
    private JTextField medmed;
    private JTextField medDat;
    private JTextField ValDat;
    private JTextField unfar;
    private JTextField regms;
    private JButton pesquisarButton;
    private JButton salvarButton;
    private JButton cancelarButton;


    ControlaMedicamento cm;
     public EditarMedicamento (ControlaMedicamento cm){
         setContentPane(JPanel);
         setTitle("Editar Medicamento");
     //    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         setLocationRelativeTo(null);
         setSize(700,400);

          DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

         pesquisarButton.addActionListener(new ActionListener() {
             @Override
             public void actionPerformed(ActionEvent e) {
                 int id = Integer.valueOf(idmed.getText());
                 Medicamento med = cm.PesquisarMed(id);


                 medmed.setText(med.getNome());
                 medDat.setText(med.getDataFabricacao().format(formatter));
                 ValDat.setText(med.getDataValidade().format(formatter));
                unfar.setText(med.getFarmacotecnica());
                regms.setText(med.getRegistroms());
             }
         });
         salvarButton.addActionListener(new ActionListener() {
             @Override
             public void actionPerformed(ActionEvent e) {
                 int id = Integer.valueOf(idmed.getText());
                 Medicamento med = cm.PesquisarMed(id);
            med.setNome(medmed.getText());
            med.setDataFabricacao(LocalDate.parse(medDat.getText(), formatter));
            med.setDataValidade(LocalDate.parse(ValDat.getText(), formatter));
            med.setFarmacotecnica(unfar.getText());
            med.setRegistroms(regms.getText());
            limparCampos();
             }
             public void limparCampos() {
                 medmed.setText("");
                 medDat.setText("");
                 ValDat.setText("");
                 unfar.setText("");
                 regms.setText("");
             }

         });
         cancelarButton.addActionListener(new ActionListener() {
             @Override
             public void actionPerformed(ActionEvent e) {
                 dispose();
             }
         });
     };





}
