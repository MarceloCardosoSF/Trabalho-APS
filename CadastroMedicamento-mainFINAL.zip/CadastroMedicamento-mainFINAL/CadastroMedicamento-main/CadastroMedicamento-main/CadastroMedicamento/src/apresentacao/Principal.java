package apresentacao;

import Negocio.Medicamento;
import apresentacao.EditarMedicamento.EditarMedicamento;
import apresentacao.ExcluirMedicamento.ExcluirMedicamento;
import persistencia.ControlaMedicamento;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Principal extends JFrame{
    private JTextField TMedicamento;
    private JTextField TDataFabricacao;
    private JButton btnSalvar;
    private JButton btnLimpar;
    private JTextArea tResultado;
    private JPanel MainPanel;
    private JTextField TPrincipioAtivo;
    private JTextField TDataValidade;
    private JList Jlist1;
    private JButton mostrarTudoButton;
    private JButton JButoon;
    private JTextField regisms;
    private JTextField unfarmac;
    private JButton EXCLUIRButton;
    private JButton EDITARButton;


    ControlaMedicamento cm = new ControlaMedicamento();
//    DefaultListModel model = new DefaultListModel();

    public DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public void limparCampos(){
        TMedicamento.setText("");
        TPrincipioAtivo.setText("");
        TDataFabricacao.setText("");
        TDataValidade.setText("");
        TMedicamento.requestFocus();
        regisms.setText(" ");
        unfarmac.setText(" ");
    }

    public Principal(){
        setContentPane(MainPanel);
        setTitle("Cadastro de Medicamento");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setSize(700,400);

        btnSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                 if ((!"".equals(TMedicamento.getText())) && (!"".equals(TPrincipioAtivo.getText())) && (!"".equals(TDataFabricacao.getText())) && (!"".equals(TDataValidade.getText())) && (!"".equals(unfarmac.getText())) && (!"".equals(regisms.getText())) ) {
                     Medicamento medicamento = new Medicamento();

                     int id = Medicamento.ProximoIdMedicamento();
                     medicamento.setId(id);

                     medicamento.setNome(TMedicamento.getText());
                     medicamento.setPrincipioAtivo(TPrincipioAtivo.getText());
                     medicamento.setDataFabricacao(LocalDate.parse(TDataFabricacao.getText(), formatter));
                     medicamento.setDataValidade(LocalDate.parse(TDataValidade.getText(), formatter));
                     medicamento.setFarmacotecnica(unfarmac.getText());
                     medicamento.setRegistroms(regisms.getText());

                     if(cm.addMedicamento(medicamento)){
                         JOptionPane.showMessageDialog(null, "Medicamento cadastrado com sucesso!");
                         limparCampos();
                         tResultado.setText(String.valueOf(cm.mostrarMedicamentos()));

                         /*model.addElement(String.valueOf(cm.mostrarMedicamentos()));

                         Jlist1.setModel(model);*/
                     }else {
                         JOptionPane.showMessageDialog(null, "Erro ao cadastrar medicamento!");
                         limparCampos();
                     }

                 } else {
                     JOptionPane.showMessageDialog(null, "Prenchimento Obrigatório dos campos!");
                     limparCampos();
                 }
            }
        });
        btnLimpar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                limparCampos();
            }
        });
        mostrarTudoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dlMostrarTudo dlg =new dlMostrarTudo(cm);
                dlg.setVisible(true);
            }
        });






        JButoon.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DLMostrarMedicamentos dlg = new DLMostrarMedicamentos(cm);
                dlg.setVisible(true);
            }
        });
        EDITARButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                EditarMedicamento editMed = new EditarMedicamento(cm);

                editMed.setVisible(true);
            }
        });

        EXCLUIRButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ExcluirMedicamento exMed = new ExcluirMedicamento(cm);
                exMed.setVisible(true);
            }
        });
    }

    public static void main(String[] args) {
        //new Principal();
    }
}
