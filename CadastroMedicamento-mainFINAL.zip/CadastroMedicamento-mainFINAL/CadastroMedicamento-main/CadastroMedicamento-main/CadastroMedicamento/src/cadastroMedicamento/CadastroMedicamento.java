package cadastroMedicamento;

import apresentacao.Principal;

public class CadastroMedicamento {
    public static void main(String[] args) {
        Principal principal = new Principal();
        principal.setVisible(true);
    }
}
//https://www.blogson.com.br/trabalhando-com-jlist-no-java/-