package Negocio;

import java.time.LocalDate;

public class Medicamento {
    private String nome;
    private String principioAtivo;
    private LocalDate dataFabricacao;
    private LocalDate dataValidade;
    private Integer id;
    private String farmacotecnica;
    private String registroms;
    public static Integer proximoIdMedicamento = 1;

    public Medicamento(String nome, String principioAtivo, LocalDate dataFabricacao, LocalDate dataValidade, Integer id, String farmacotecnica, String registroms) {
        this.setNome(nome);
        this.setPrincipioAtivo(principioAtivo);
        this.setDataFabricacao(dataFabricacao);
        this.setDataValidade(dataValidade);
        this.setId(id);
        this.setFarmacotecnica(farmacotecnica);
        this.setRegistroms(registroms);
    }

    public Medicamento() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getPrincipioAtivo() {
        return principioAtivo;
    }

    public void setPrincipioAtivo(String principioAtivo) {
        this.principioAtivo = principioAtivo;
    }

    public LocalDate getDataFabricacao() {
        return dataFabricacao;
    }

    public void setDataFabricacao(LocalDate dataFabricacao) {
        this.dataFabricacao = dataFabricacao;
    }

    public LocalDate getDataValidade() {
        return dataValidade;
    }

    public void setDataValidade(LocalDate dataValidade) {
        this.dataValidade = dataValidade;
    }

    public Integer getId() { return id; }

    public void setId(Integer id) { this.id = id; }

    public String getFarmacotecnica() { return farmacotecnica; }

    public void setFarmacotecnica(String farmacotecnica) { this.farmacotecnica = farmacotecnica; }

    public String getRegistroms() { return registroms; }

    public void setRegistroms(String registroms) { this.registroms = registroms; }

    public static int ProximoIdMedicamento(){
        return proximoIdMedicamento++;
    }
    @Override
    public String toString() {
        return  "ID: " + id +
                "\nMedicamento ='" + nome + '\'' +
                ", Principio Ativo ='" + principioAtivo + '\'' +
                ", Fabricacao ='" + dataFabricacao + '\'' +
                ", Validade ='" + dataValidade +
                ", Unidade Farmacotécnica = " + farmacotecnica +
                ", Registro M.S: " + registroms;
    }
}

