import apresentacao.Principal;

import javax.swing.*;

public class EditarMedicamento extends JFrame {
    private JPanel panel1;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JTextField textField5;
    private JTextField textField6;
    private JButton pesquisarButton;
    private JButton salvarButton;
    private JButton cancelarButton;

}
